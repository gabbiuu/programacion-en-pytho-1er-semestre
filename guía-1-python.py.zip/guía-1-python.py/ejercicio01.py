a= 'la Universidad de los Lagos es una institucion estatal fundada en 1993. Esta universidad regional entrega una contribucion significativa al desarrollo sostenible del territorio. Como Universidad sus pilares fundamentales se basan en la inclusion, pluralismo, conciencia ambiental y participacion democratica.'
print(a)
print(type(a))
b= a.lower()
print(b)
c= b.count("universidad")
print("\n")
print ("la palabra universidad se repite ", c , "veces")


