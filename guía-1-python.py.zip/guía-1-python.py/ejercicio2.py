
num1 = []
for i in range(500,800,10) :
    num1.append(i)
print(num1)
    
num2 = []
for i in range(456,-2,-2) : 
    num2.append(i)
print(num2)

a = sum(num2)
b = sum(num1)   

suma = (a+b)
print(suma)

